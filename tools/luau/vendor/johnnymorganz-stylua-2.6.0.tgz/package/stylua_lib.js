/* @ts-self-types="./stylua_lib.d.ts" */

import * as wasm from "./stylua_lib_bg.wasm";
import { __wbg_set_wasm } from "./stylua_lib_bg.js";
__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    BlockNewlineGaps, CallParenType, CollapseSimpleStatement, Config, IndentType, LineEndings, LuaVersion, OutputVerification, QuoteStyle, Range, SortRequiresConfig, SpaceAfterFunctionNames, formatCode
} from "./stylua_lib_bg.js";
